path = 'index.html'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()

replacements = {
    'é': '�', 'ã': '�', 'í': '�', 'ç': '�', 'õ': '�', 'ê': '�', 'á': '�', 'ó': '�',
    '·': '�', '–': '�', '↓': '?', '→': '?',
    '🚚': '??', '📦': '??', '� �� ': '???', '� ': '??', '📱': '??', '� ': '??', '📌': '??',
    'Olá': 'Ol�', 'Pré-Moldados': 'Pr�-Moldados', 'Orçamento': 'Or�amento', 'orçamento': 'or�amento',
    'Localização': 'Localiza��o', 'Bras�\xadlia': 'Bras�lia', 'resistência': 'resist�ncia',
    'Catálogo': 'Cat�logo', 'especificações': 'especifica��es', 'técnicas': 't�cnicas',
    'calçadas': 'cal�adas', 'áreas': '�reas', 'estratégica': 'estrat�gica', 'Horário': 'Hor�rio',
    'Sábado': 'S�bado', 'rápida': 'r�pida', 'Fabricação': 'Fabrica��o'
}

for bad, good in replacements.items():
    text = text.replace(bad, good)

text = text.replace('<img src="imagens/blocos.jpg" alt="Blocos de Concreto" class="card-img">', '<img src="imagens/blocos.jpg" alt="Blocos de Concreto" class="card-img" style="object-fit: contain; background: #cbd5e1; padding: 15px;">')

with open(path, 'w', encoding='utf-8', newline='') as f:
    f.write(text)
