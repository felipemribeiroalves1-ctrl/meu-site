import os
path = 'index.html'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()

# Remove BOM if present
if text.startswith('\ufeff'):
    text = text[1:]

try:
    # Fix the double encoding
    fixed_text = text.encode('windows-1252').decode('utf-8')
    with open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(fixed_text)
    print('Encoding fixed!')
except Exception as e:
    print('Failed:', e)
